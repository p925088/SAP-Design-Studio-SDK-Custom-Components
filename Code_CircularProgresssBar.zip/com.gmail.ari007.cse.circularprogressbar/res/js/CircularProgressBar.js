/**
 Copyright (c) 2017 Arijit Das

 Permission is hereby granted, free of charge, to any person
 obtaining a copy of this software and associated documentation
 files (the "Software"), to deal in the Software without
 restriction, including without limitation the rights to use,
 copy, modify, merge, publish, distribute, sub-license, and/or sell
 copies of the Software, and to permit persons to whom the
 Software is furnished to do so, subject to the following
 conditions:

 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 OTHER DEALINGS IN THE SOFTWARE.
 */

/* ---------- Set default properties ---------- */
function cpbDefaultSettings(){
    return {
    	leftMargin: 10,				// Left margin for the chart.
        topMargin: 10,				// Top margin for the chart.
        rightMargin: 10,			// Right margin for the chart.
        bottomMargin: 10,			// Bottom margin for the chart.
        trackColor: "#dddddd",		// Color of track.
        progressColor: "orange",	// Color of progress bar.
        trackWidth: 5,				// Width of track.
        progressWidth: 10,			// Width of progress bar.
        valueDisplay: true,			// Display values.
        opacity: 0.9				// Opacity of track.
    };
}



/* ---------- Progress Bar ---------- */
function circularProgressBar(container, elementId, data, config){
	if(config == null) config = cpbDefaultSettings();
	
	var vis = d3.select("#" + elementId);
	
	var width = vis.style("width").replace("px","");
	var height = vis.style("height").replace("px","");	
	
	var label = data.toFixed(2) + '%';
	if(data > 100) data = 100;
	else if(data <0) {
		data = 0;
		label = '';
	}
	var radius = Math.min((width - config.leftMargin - config.rightMargin), (height - config.topMargin - config.bottomMargin)) / 2;
	
	var circleCenterX = config.leftMargin +  radius,
		circleCenterY = config.topMargin + radius;
	
	radius -= Math.max(config.trackWidth, config.progressWidth) / 2;
	
	var arcTrack = d3.svg.arc()
	    		.innerRadius(radius - config.trackWidth / 2)
	    		.outerRadius(radius + config.trackWidth / 2) 
	    		.startAngle(0);
	
	var progressTrack = d3.svg.arc()
				.innerRadius(radius - config.progressWidth / 2)
				.outerRadius(radius + config.progressWidth / 2)
				.startAngle(0);
		
		
	var track = vis.append("g").attr("transform", "translate(" + circleCenterX + "," + circleCenterY + ")");
	track.append("path")
			.datum({endAngle: Math.PI * 2})
			.style("fill", config.trackColor)
			.style("opacity", config.opacity)
			.attr("d", arcTrack)
			.attr("class", "cpb_Track");
	
	var bar = vis.append("g").attr("transform", "translate(" + circleCenterX + "," + circleCenterY + ")");
	bar.append("path")
			.datum({endAngle: data *Math.PI * 2 / 100})
			.style("fill", config.progressColor)
			.style("opacity", config.opacity)
			.attr("d", progressTrack)
			.attr("class", "cpb_Progress");
	
	if (config.valueDisplay) var label = vis.append("text").text(label)
					.attr("x", circleCenterX).attr("y", circleCenterY)
					.attr("font-size", radius / 2 + "px")
					.attr("text-anchor", "middle")
					.attr("dominant-baseline", "central")
					.attr("class", "cpb_Label");
			

	return this;	

}

