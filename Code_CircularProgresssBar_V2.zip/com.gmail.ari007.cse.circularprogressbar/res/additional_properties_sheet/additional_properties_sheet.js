sap.designstudio.sdk.PropertyPage.subclass("com.gmail.ari007.cse.circularprogressbar.CircularProgressBar",  function() {

	
});