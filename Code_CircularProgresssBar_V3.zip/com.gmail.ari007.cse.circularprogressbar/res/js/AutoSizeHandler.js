/**
 * 
 */

var resizableComponents = [],
	onWindowResizeInserted = false,
	resizeHolder = false;


function onWindowResize() {
	if(resizeHolder !== false) {
		clearTimeout(resizeHolder);
	}
    
	resizeHolder = setTimeout(onWindowResizeExecutor, 200);
}

function onWindowResizeExecutor() {
	for (var compIndex in resizableComponents) {
		var component = resizableComponents[compIndex];
		
		if(component._oResize){
			component._oResize();
		}
	}
}

function determineOwnSize(parent, resizeTrigger) {
		var orgParent = parent;
	
		var sizeChanged = false;
	
		// in case the component is on auto resize mode
		if(orgParent.oComponentProperties) {
			if(orgParent.oComponentProperties.width == "auto" || orgParent.oComponentProperties.height == "auto") {
				parent = findParentContainer(parent);	
			}
	
			var jqThis = parent.$();
			
			var outerSizeRead = "";
			if(orgParent.oComponentProperties.width == "auto") {
				orgParent._containerWidth = jqThis.outerWidth(true);
				outerSizeRead = "W";
			} else {
				if(orgParent.oComponentProperties.width) {
					orgParent._containerWidth = parseInt(orgParent.oComponentProperties.width);
				}
			}
			
			if(orgParent.oComponentProperties.height == "auto") {
				orgParent._containerHeight = jqThis.outerHeight(true);
				outerSizeRead = outerSizeRead + "H";
			} else {
				if(orgParent.oComponentProperties.height) {
					orgParent._containerHeight = parseInt(orgParent.oComponentProperties.height);	
				}
			}
			
			if (orgParent.oComponentProperties && outerSizeRead.indexOf("W") > -1) {
				if(orgParent.oComponentProperties.width == "auto") {
					orgParent._containerWidth = orgParent._containerWidth - orgParent.oComponentProperties.leftmargin;
					orgParent._containerWidth = orgParent._containerWidth - orgParent.oComponentProperties.rightmargin;
				}	
			}
			
			if (orgParent.oComponentProperties && outerSizeRead.indexOf("H") > -1) {
				if(orgParent.oComponentProperties.height == "auto") {
					orgParent._containerHeight = orgParent._containerHeight - orgParent.oComponentProperties.topmargin;
					orgParent._containerHeight = orgParent._containerHeight - orgParent.oComponentProperties.bottommargin;
				}
			}
	
			if(parent.zenControlType == "tabstrip") {
				var line = jqThis.children()[0];
				if(line) {
					orgParent._containerHeight = orgParent._containerHeight-line.clientHeight;
				}
			}			
	
			if(orgParent._oldContainerWidth != orgParent._containerWidth) {
				sizeChanged = true;
				if(resizeTrigger) orgParent._oldContainerWidth = orgParent._containerWidth;
			}
			if(orgParent._oldContainerHeight != orgParent._containerHeight) {
				sizeChanged = true;
				if(resizeTrigger) orgParent._oldContainerHeight = orgParent._containerHeight;
			}
		}
	
		return sizeChanged;
}


function resizeContentAbsoluteLayout(parent, mainObject, callback) {
		if(parent._oContentPlaced != true) {
			if(parent.addContent && !mainObject.dummy) {
				parent.addContent(
						mainObject,
						{left: "0px", top: "0px"}
				);
			}
			
			parent._oResize = function(ignoreOwner, forced) {
				var changed = determineOwnSize(parent, true);
	
				if(changed || forced) {
					if(mainObject && mainObject.setWidth) {
						mainObject.setWidth(parent._containerWidth-2 + "px");	
					}
					
					if(mainObject && mainObject.setHeight) {
						mainObject.setHeight(parent._containerHeight-2 + "px");	
					}
					
					if(!ignoreOwner) {
						if(parent.setWidth) {
							parent.setWidth(parent._containerWidth + "px", true);	
						}
						
						if(parent.setHeight) {
							parent.setHeight(parent._containerHeight + "px", true);	
						}
					}
					
					if(callback) {
						callback(parent._containerWidth, parent._containerHeight, parent);
					}
				}
			};
			
			
			if(!parent._oEventREgistered) {
				// attach resize handler once
				addEvent(parent.$()[0], "resize", parent._oResize);
				resizableComponents.push(parent);
				parent._oEventREgistered = true;
			}
			
			// attach resize handler
			if(!onWindowResizeInserted) {
				addEvent(window, "resize", onWindowResize);onWindowResizeInserted=true;
			}
			
			// call resize handler
			setTimeout(function() {
				var myVar = parent;
				if(myVar.$()[0]) {myVar.$()[0].style.display = "block";}
				myVar._oResize();
			}, 100);
	
			// parent.$()[0].style.display = "none";
			
			// redefine the layout functions
			var currentWidthFunction = parent.setWidth;
			var currentHeightFunction = parent.setHeight;
	
			if(currentWidthFunction) {
				parent.setWidth = function (value, doNotResizeAgain) {
					var r = currentWidthFunction.call(parent, value);
					if(!doNotResizeAgain) {
						parent._oResize(true);
					}
					
					return r;
				};
			} else {
				parent.setWidth = function (value, doNotResizeAgain) {
					if(!doNotResizeAgain) {
						parent._oResize(true);
					}
					
					return parent;
				};
			}
			if(currentHeightFunction) {
				parent.setHeight = function (value, doNotResizeAgain) {
					var r = currentHeightFunction.call(parent, value);
					if(!doNotResizeAgain) {
						parent._oResize(true);
					}
					
					return r;
				};
			} else {
				parent.setHeight = function (value, doNotResizeAgain) {
					if(!doNotResizeAgain) {
						parent._oResize(true);
					}
					
					return parent;
				};
			}
			
			parent._oContentPlaced = true;
		};
}

function addEvent(elem, type, eventHandle) {
    if (elem == null || typeof(elem) == 'undefined') return;
    if ( elem.addEventListener ) {
        elem.addEventListener( type, eventHandle, false );
    } else if ( elem.attachEvent ) {
        elem.attachEvent( "on" + type, eventHandle );
    } else {
        elem["on"+type]=eventHandle;
    }
}

function findParentContainer(parent) {
	var myParent = parent;
	
	var max = 25;
	var counter = 0;
	
	while(myParent.zenControlType == undefined || myParent.zenControlType == "tab" ||  myParent.zenControlType.indexOf("sdk") == 0) {
		myParentParent = undefined;
		if(myParent.getParent != undefined) {
			myParentParent = myParent.getParent();
		}
		if(myParentParent == undefined && myParent.owner != undefined) {
			myParentParent = myParent.owner;
		}
		
		if(myParentParent != undefined) {
			myParent = myParentParent;
		}
		
		if(!myParent || counter > max) {
			break;
		}
		
		counter = counter + 1;
	}
	
	return myParent;
}
	