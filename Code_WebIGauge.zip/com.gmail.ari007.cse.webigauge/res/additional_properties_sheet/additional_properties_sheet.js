sap.designstudio.sdk.PropertyPage.subclass("com.gmail.ari007.cse.webigauge.Gauge",  function() {

	
});