/**
 Copyright (c) 2017 Arijit Das

 Permission is hereby granted, free of charge, to any person
 obtaining a copy of this software and associated documentation
 files (the "Software"), to deal in the Software without
 restriction, including without limitation the rights to use,
 copy, modify, merge, publish, distribute, sub-license, and/or sell
 copies of the Software, and to permit persons to whom the
 Software is furnished to do so, subject to the following
 conditions:

 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 OTHER DEALINGS IN THE SOFTWARE.
 */

define(["sap/designstudio/sdk/component", "css!../css/component.css"], function(Component, css) {
	Component.subclass("com.gmail.ari007.cse.webigauge.Gauge", function() {

		var me = this;
		
		//Properties
		me._config = wgDefaultSettings();
		me._data = 65.64567;
		me._trackColor = "#dddddd";		// Color of track.
        me._progressColor = "orange";	// Color of progress bar.
        me._trackWidth = 30;			// Width of track.
        me._progressWidth = 30;			// Width of progress bar.
        me._valueDisplay = true;		// Display value.
        me._opacity = 0.9;				// Opacity of track.
        me._targetWidth = 40;			// Width of target bar.        
        me._rangeDisplay = true;		// Display range.
        me._showAsPercentage = true;	// Display values as percentage.
        me._showTarget = true;			// Display target marker.
        me._minValue = 0;				// Minimum value.
        me._maxValue = 100;				// Maximum value.
        me._targetValue = 60;			// Target value
		
		//Getters for the height and width of the component
		me.getWidth = function(){
			return me.$().width();
		};
	
		me.getHeight = function(){
			return me.$().height();
		};
	
		
		//Getters and Setters for other properties
		me.opacity = function(value) {
			if (value === undefined) {
				return me._opacity;
			} else {
				if(value < 0 || value > 1) alert("Valid range: 0 - 1");
				else{
					me._opacity = value;
				}			
				return this;
			}
		};
		
		me.trackColor = function(value) {
			if (value === undefined) {
				return me._trackColor;
			} else {
				me._trackColor = value;
				return this;
			}
		};
		
		me.progressColor = function(value) {
			if (value === undefined) {
				return me._progressColor;
			} else {
				me._progressColor = value;
				return this;
			}
		};
		
		me.data = function(value) {
			if (value === undefined) {
				return me._data;
			} else {
				me._data = value;
				return this;
			}
		};
		
		me.minValue = function(value) {
			if (value === undefined) {
				return me._minValue;
			} else {
				me._minValue = value;
				return this;
			}
		};
		
		me.maxValue = function(value) {
			if (value === undefined) {
				return me._maxValue;
			} else {
				me._maxValue = value;
				return this;
			}
		};
		
		me.targetValue = function(value) {
			if (value === undefined) {
				return me._targetValue;
			} else {
				me._targetValue = value;
				return this;
			}
		};
		
		me.trackWidth = function(value) {
			if (value === undefined) {
				return me._trackWidth;
			} else {
				if(value < 20 || value > 50) alert("Valid range: 20 - 50");
				else{
					me._trackWidth = value;
				}			
				return this;
			}
		};
		
		me.progressWidth = function(value) {
			if (value === undefined) {
				return me._progressWidth;
			} else {
				if(value < 20 || value > 50) alert("Valid range: 20 - 50");
				else{
					me._progressWidth = value;
				}			
				return this;
			}
		};
		
		me.targetWidth = function(value) {
			if (value === undefined) {
				return me._targetWidth;
			} else {
				if(value < 20 || value > 50) alert("Valid range: 20 - 50");
				else{
					me._targetWidth = value;
				}			
				return this;
			}
		};
		
		me.valueDisplay = function(value) {
			if ( value === undefined ) {
				return me._valueDisplay;
			} else {
				me._valueDisplay = value;
				return this;
			}
		};
		
		me.rangeDisplay = function(value) {
			if ( value === undefined ) {
				return me._rangeDisplay;
			} else {
				me._rangeDisplay = value;
				return this;
			}
		};
		
		me.showAsPercentage = function(value) {
			if ( value === undefined ) {
				return me._showAsPercentage;
			} else {
				me._showAsPercentage = value;
				return this;
			}
		};
		
		me.showTarget = function(value) {
			if ( value === undefined ) {
				return me._showTarget;
			} else {
				me._showTarget = value;
				return this;
			}
		};
		
		var parentInit = this.init;
    	this.init = function(){
    		parentInit.call(this);
    		this.$().addClass("myCPB");
    		this.tagCanvas = document.createElement("canvas");
    		this.$().append($(this.tagCanvas));
    		
    		if(!this._oContentPlaced) {
    			var dummy = {};
    			dummy.dummy = true;
    			
    			resizeContentAbsoluteLayout(this, dummy, this.onResize);
    		}
    	};
    	
    	var parentAfterUpdate = this.afterUpdate;
		this.afterUpdate = function(){
			parentAfterUpdate.call(this);
			this.drawChart();
		};
		
		this.onResize = function (width, height, parent) {
			parent.drawChart();
		};
		

		this.drawChart = function() {
			
			var myDiv = me.$()[0];
			d3.select(myDiv).selectAll("*").remove();
			
			var container = d3.select(myDiv);			
			
			var instanceID = "myWG_" + container.attr("id");
			
			var vis = container.append("svg:svg")			
						.attr("width", "100%")
						.attr("height", "100%")
						.attr("id", instanceID);
			
			
			me._config.trackColor = me._trackColor;
			me._config.progressColor = me._progressColor;
			me._config.trackWidth = me._trackWidth;
			me._config.progressWidth = me._progressWidth;
			me._config.valueDisplay = me._valueDisplay;
			me._config.opacity = me._opacity;
			me._config.targetWidth = me._targetWidth;
			me._config.rangeDisplay = me._rangeDisplay;
			me._config.showAsPercentage = me._showAsPercentage;
			me._config.showTarget = me._showTarget;
			me._config.minValue = me._minValue;
			me._config.maxValue = me._maxValue;
			me._config.targetValue = me._targetValue;		
						
			
			if(me._config.minValue < me._config.maxValue){
				var wg = drawMyGauge(container, instanceID, me._data, me._config);			
			}
			
		};
	});
});