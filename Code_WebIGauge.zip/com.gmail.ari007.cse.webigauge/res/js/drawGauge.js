/**
 Copyright (c) 2017 Arijit Das

 Permission is hereby granted, free of charge, to any person
 obtaining a copy of this software and associated documentation
 files (the "Software"), to deal in the Software without
 restriction, including without limitation the rights to use,
 copy, modify, merge, publish, distribute, sub-license, and/or sell
 copies of the Software, and to permit persons to whom the
 Software is furnished to do so, subject to the following
 conditions:

 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 OTHER DEALINGS IN THE SOFTWARE.
 */

/* ---------- Set default properties ---------- */
function wgDefaultSettings(){
    return {
    	leftMargin: 10,				// Left margin for the chart.
        topMargin: 10,				// Top margin for the chart.
        rightMargin: 10,			// Right margin for the chart.
        bottomMargin: 10,			// Bottom margin for the chart.
        labelMargin: 15,			// Margin for the value label
        trackColor: "#dddddd",		// Color of track.
        progressColor: "orange",	// Color of progress bar.
        trackWidth: 30,				// Width of track.
        progressWidth: 30,			// Width of progress bar.
        targetWidth: 40,			// Width of target bar.
        valueDisplay: true,			// Display value.
        rangeDisplay: true,			// Display range.
        showAsPercentage: true,		// Display values as percentage.
        showTarget: true,			// Display target marker.
        minValue: 0,				// Minimum value.
        maxValue: 100,				// Maximum value.
        opacity: 0.9,				// Opacity of track.
        targetValue: 60				// Target value
    };
}

function drawMyGauge(container, elementId, data, config){

	if(config == null) config = wgDefaultSettings();
	
	var vis = d3.select("#" + elementId);
	
	var width = $("#" + elementId).width();
	var height = $("#" + elementId).height();	
	
	var label = data.toFixed(0) + (config.showAsPercentage ? '%' : '');
	
	if(data > config.maxValue) data = config.maxValue;
	else if(data < config.minValue) data = config.minValue;
	var rangeLength = config.maxValue - config.minValue;
	
	var radius = Math.min((width - config.leftMargin - config.rightMargin), (height - config.topMargin - config.bottomMargin - config.labelMargin)*2) / 2;
	
	var circleCenterX = width/2,
		circleCenterY = height - config.bottomMargin - config.labelMargin;
	
	radius -= Math.max(config.trackWidth, config.progressWidth) / 2;
	
	var arcTrack = d3.svg.arc()
	    		.innerRadius(radius - config.trackWidth / 2)
	    		.outerRadius(radius + config.trackWidth / 2) 
	    		.startAngle(-1 * Math.PI / 2);
	
	var progressTrack = d3.svg.arc()
				.innerRadius(radius - config.progressWidth / 2)
				.outerRadius(radius + config.progressWidth / 2)
				.startAngle(-1 * Math.PI / 2);
	
	var targetTrack = d3.svg.arc()
				.innerRadius(radius - config.targetWidth / 2)
				.outerRadius(radius + config.targetWidth / 2)
				.startAngle(((config.targetValue - config.minValue) * Math.PI / rangeLength) - (Math.PI / 2));
	
	var track = vis.append("g").attr("transform", "translate(" + circleCenterX + "," + circleCenterY + ")");
	track.append("path")
			.datum({endAngle: Math.PI / 2})
			.style("fill", config.trackColor)
			.style("stroke", d3.hsl(config.trackColor).darker(1))
			.style("stroke-width", 1)
			.style("opacity", config.opacity)
			.attr("d", arcTrack)
			.attr("class", "wg_Track");
	
	var bar = vis.append("g").attr("transform", "translate(" + circleCenterX + "," + circleCenterY + ")");
	var radialGradient = bar.append("defs")
	  .append("radialGradient")
	    .attr("id", "radial-gradient");

	radialGradient.append("stop")
	    .attr("offset", "0%")
	    .attr("stop-color", d3.hsl(config.progressColor).brighter(1));

	radialGradient.append("stop")
	    .attr("offset", "100%")
	    .attr("stop-color", config.progressColor);
	
	bar.append("path")
			.datum({endAngle: ((data - config.minValue) * Math.PI / rangeLength) - (Math.PI / 2)})
			.style("fill", "url(#radial-gradient)")
			.style("opacity", config.opacity)
			.attr("d", progressTrack)
			.attr("class", "wg_Progress");
	
	if(config.showTarget && config.targetValue >= config.minValue && config.targetValue <= config.maxValue){
		var target = vis.append("g").attr("transform", "translate(" + circleCenterX + "," + circleCenterY + ")");
		target.append("path")
		.datum({endAngle: ((config.targetValue - config.minValue) * Math.PI / rangeLength) - (Math.PI / 2) + (Math.PI / 180)})		
		.attr("d", targetTrack)
		.attr("class", "wg_Target");
	}	
	
	if (config.valueDisplay) var label = vis.append("text").text(label)
	.attr("x", circleCenterX).attr("y", circleCenterY)
	.attr("font-size", radius / 50 + "em")
	.attr("text-anchor", "middle")
	.attr("class", "wg_ValueLabel");
	
	
	var minLabelX = circleCenterX - radius,
		minLabelY = circleCenterY + config.labelMargin,
		maxLabelX = circleCenterX + radius,
		maxLabelY = circleCenterY + config.labelMargin;
	
	if(config.rangeDisplay){
		vis.append("text").text(config.minValue + (config.showAsPercentage ? '%' : ''))
		.attr("x", minLabelX).attr("y", minLabelY)
		.attr("id", "minLabel")
		.attr("font-size", "12px")
		.attr("text-anchor", "middle")
		.attr("class", "wg_RangeLabel");		
		
		vis.append("text").text(config.maxValue + (config.showAsPercentage ? '%' : ''))
		.attr("x", maxLabelX).attr("y", maxLabelY)
		.attr("id", "maxLabel")
		.attr("font-size", "12px")
		.attr("text-anchor", "middle")
		.attr("class", "wg_RangeLabel");
	}
	

	return this;	
	
}